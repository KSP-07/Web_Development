
<?php
$servername = "localhost";  
$username = "root";  
$password = ""; 
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$conn = mysqli_connect("localhost:3306", "root", "","dbm");
if($conn === false){
    
    die("ERROR: Could not connect. " 
    
    . mysqli_connect_error());
    
}
// get the post records
$fname = $_REQUEST['fname'];
$lname = $_REQUEST['lname'];
$DOB = $_REQUEST['DOB'];
$gender = $_REQUEST['gender'];
$email = $_REQUEST['email'];
$contact = $_REQUEST['contact'];
$destination = $_REQUEST['destination'];
$people = $_REQUEST['people'];

// database insert SQL code
$sql = "INSERT INTO bookings  VALUES ('$fname','$lname','$DOB','$gender','$email','$contact','$destination','$people')";


// insert in database 
// $rs = mysqli_query($conn, $sql);

if(mysqli_query($conn, $sql)){
    if($people==="1"){
        echo nl2br("details has been saved\n\nYou will recieve a link on your Contact Number within an hour to pay Rs. 1000 , after successfull payment your tickets would be sent to your mail-id.\nThank you for choosing our services");
    }
    else if($people==="2"){

        echo nl2br("details has been saved\n\nYou will recieve a link on your Contact Number within an hour to pay Rs. 2000 , after successfull payment your tickets would be sent to your mail-id.\nThank you for choosing our services");
    }
    else if($people==="3"){

        echo nl2br("details has been saved\n\nYou will recieve a link on your Contact Number within an hour to pay Rs. 3000 , after successfull payment your tickets would be sent to your mail-id.\nThank you for choosing our services");
    }
    else if($people==="4"){

        echo nl2br("details has been saved\n\nYou will recieve a link on your Contact Number within an hour to pay Rs. 4000 , after successfull payment your tickets would be sent to your mail-id.\nThank you for choosing our services");
    }
}


else{
    
    echo "Some error occured.";
    
}

mysqli_close($conn);

?>
