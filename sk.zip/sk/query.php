
<?php
$servername = "localhost";  
$username = "root";  
$password = ""; 
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$conn = mysqli_connect("localhost:3307", "root", "","dbm");
if($conn === false){
    
    die("ERROR: Could not connect. " 
    
    . mysqli_connect_error());
    
}
// get the post records
$query = $_REQUEST['query'];

// database insert SQL code
$sql = "INSERT INTO query  VALUES ('$query')";


// insert in database 
// $rs = mysqli_query($conn, $sql);

if(mysqli_query($conn, $sql)){
    
    echo "details has been saved";
    
}

else{
    
    echo "Some error occured.";
    
}

mysqli_close($conn);

?>
